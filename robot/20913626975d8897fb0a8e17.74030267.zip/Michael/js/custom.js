
$(document).ready(function () {

	$('.close').click(function () {
		$('.navbar-collapse').removeClass('show');
	});

  	if($(window).width() <= 540) {
		$('.footer-inner h5').click(function () {
		    $(this).next('ul').slideToggle();
		    $(this).toggleClass('panel-active');
		});
  	}

});

